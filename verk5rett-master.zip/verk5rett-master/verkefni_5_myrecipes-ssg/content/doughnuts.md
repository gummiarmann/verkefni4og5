---
title: Old Fashioned Doughnuts
date: 2019-04-14
tags: Sweet
thumbnail: img/doughnuts.jpg
summary: Old fashioned sugar dusted doughnuts. Better than any store bought doughnuts.
slug: doughnuts
---

__Ingredients__

+ 4 cups bread flour
+ 2 tblspoon sugar
+ 1 tblspoon yeast
+ 1 tsp salt
+ 2 tblspoon milk powder
+ Water as req.
+ Castor sugar to coat doughnuts

__Preparation__

Mix all ingredients and knead until a slightly tacky dough form. Cover and let rise until doubled in size. Roll into half an inch-thick rectangle. Cut small rounds. Let the rounds of dough rise for 10-15 minutes then fry in medium hot oil. Roll in castor sugar and serve straight away.
