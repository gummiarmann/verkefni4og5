---
title: Faux French Bread
date: 2019-04-17
tags: Bread
thumbnail: img/bread.jpg
summary: Not quite french bread which has great taste and stays fresh for longer.
slug: french-bread
---

__Ingredients__

+ 4 cups bread flour
+ 1 tblspoon yeast
+ 2 tblspoon sugar
+ 1.5 tsp salt
+ 2 tblspoon oil
+ Water as required.

__Preparation__

Mix all ingredients and knead until a slightly tacky dough forms. Cover and let rise until doubled in size. Divide into 4 equal portions. Roll each portion into a baguette shape. Let rise on a parchment covered baking sheet. Bake at 240C or until nicely browned.
