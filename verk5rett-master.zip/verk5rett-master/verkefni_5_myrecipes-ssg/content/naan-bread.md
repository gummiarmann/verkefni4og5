---
title: Naan Bread
date: 2019-04-13
tags: Bread
thumbnail: img/naan.jpg
summary: Soft and fluffy home made naan bread which doesn't need you to fire up the oven. Great with curries or tear chunks and dunk in honey butter.
slug: naan
---

__Ingredients__

+ 4 cups bread flour
+ 1 tsp yeast
+ 1 tblspoon sugar
+ 1 tsp salt
+ 1 tblspoon ghee
+ 2 tblspoon yoghurt
+ ¼ cup milk
+ Water as req

__Preparation__

Mix all the ingredients and knead until smooth. Let rise until doubled. Divide into 12 pieces. Roll each piece around 6 inches in diameter. Cook on a very hot cast iron skillet or grill. Apply a little ghee on the top side before removing from the pan. Serve warm.
